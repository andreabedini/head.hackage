# ghc-check

[![GitHub CI](https://github.com/pepeiborra/ghc-check/workflows/CI/badge.svg)](https://github.com/pepeiborra/ghc-check/actions)

Use Template Haskell to record the ghc api version at compile time and detect mismatches with the run time version.