{-# LANGUAGE CPP #-}
{-# LANGUAGE MagicHash #-}
module Basement.HeadHackageUtils where

import GHC.Exts

#if __GLASGOW_HASKELL__ >= 903
and64Compat# :: Word64# -> Word64# -> Word64#
and64Compat# = and64#

int64ToIntCompat# :: Int64# -> Int#
int64ToIntCompat# = int64ToInt#

intToInt64Compat# :: Int# -> Int64#
intToInt64Compat# = intToInt64#

int64ToWord64Compat# :: Int64# -> Word64#
int64ToWord64Compat# = int64ToWord64#

or64Compat# :: Word64# -> Word64# -> Word64#
or64Compat# = or64#

plusInt64Compat# :: Int64# -> Int64# -> Int64#
plusInt64Compat# = plusInt64#

plusWord64Compat# :: Word64# -> Word64# -> Word64#
plusWord64Compat# = plusWord64#

uncheckedShiftL64Compat# :: Word64# -> Int# -> Word64#
uncheckedShiftL64Compat# = uncheckedShiftL64#

uncheckedShiftRL64Compat# :: Word64# -> Int# -> Word64#
uncheckedShiftRL64Compat# = uncheckedShiftRL64#

word64ToInt64Compat# :: Word64# -> Int64#
word64ToInt64Compat# = word64ToInt64#

word64ToWordCompat# :: Word64# -> Word#
word64ToWordCompat# = word64ToWord#

wordToWord64Compat# :: Word# -> Word64#
wordToWord64Compat# = wordToWord64#

xor64Compat# :: Word64# -> Word64# -> Word64#
xor64Compat# = xor64#
#else
and64Compat# :: Word# -> Word# -> Word#
and64Compat# = and#

int64ToIntCompat# :: Int# -> Int#
int64ToIntCompat# x = x

intToInt64Compat# :: Int# -> Int#
intToInt64Compat# x = x

int64ToWord64Compat# :: Int# -> Word#
int64ToWord64Compat# = int2Word#

or64Compat# :: Word# -> Word# -> Word#
or64Compat# = or#

plusInt64Compat# :: Int# -> Int# -> Int#
plusInt64Compat# = (+#)

plusWord64Compat# :: Word# -> Word# -> Word#
plusWord64Compat# = plusWord#

uncheckedShiftL64Compat# :: Word# -> Int# -> Word#
uncheckedShiftL64Compat# = uncheckedShiftL#

uncheckedShiftRL64Compat# :: Word# -> Int# -> Word#
uncheckedShiftRL64Compat# = uncheckedShiftRL#

word64ToInt64Compat# :: Word# -> Int#
word64ToInt64Compat# = word2Int#

word64ToWordCompat# :: Word# -> Word#
word64ToWordCompat# x = x

wordToWord64Compat# :: Word# -> Word#
wordToWord64Compat# x = x

xor64Compat# :: Word# -> Word# -> Word#
xor64Compat# = xor#
#endif
