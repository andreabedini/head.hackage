HGeometry-combinatorial
=======================

The combinatorial types for the [HGeometry](https://hackage.haskell.org/package/hgeometry) package.
