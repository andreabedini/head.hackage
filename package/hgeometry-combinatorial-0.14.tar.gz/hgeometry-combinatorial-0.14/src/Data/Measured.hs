--------------------------------------------------------------------------------
-- |
-- Module      :  Data.Measured
-- Copyright   :  (C) Frank Staals
-- License     :  see the LICENSE file
-- Maintainer  :  Frank Staals
--------------------------------------------------------------------------------
module Data.Measured( module Data.Measured.Class
                    ) where

import Data.Measured.Class
