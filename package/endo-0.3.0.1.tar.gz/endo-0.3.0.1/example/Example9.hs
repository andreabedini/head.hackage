{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE FlexibleInstances #-}

module Main where

import Data.Functor.Identity

import Data.Text (Text)

import Data.Monoid.Endo
import Data.Monoid.Endo.AnEndo

import Data.Default.Class (Default(def))


data User f g = User
    { _login :: Text
    , _name :: f Text
    , _displayName :: f Text
    , _password :: g Text
    }

type CreateUser = User Maybe Identity
type ShowUser = User Maybe Proxy
type AuthenticateUser = User Proxy Identity
