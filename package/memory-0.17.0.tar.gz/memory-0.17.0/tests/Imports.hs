module Imports
    ( module X
    ) where

import Prelude as X (zip)
import Control.Monad as X (replicateM)
import Data.List as X (concatMap)

import Foundation as X
import Foundation.Collection as X (nonEmpty_)
import Foundation.Check as X
