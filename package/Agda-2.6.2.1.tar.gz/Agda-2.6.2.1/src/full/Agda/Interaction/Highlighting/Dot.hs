module Agda.Interaction.Highlighting.Dot
  ( dotBackend
  ) where

import Agda.Interaction.Highlighting.Dot.Backend ( dotBackend )
