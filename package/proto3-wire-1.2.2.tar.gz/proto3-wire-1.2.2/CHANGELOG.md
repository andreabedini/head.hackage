1.2.2
  - Add new `zigZag{Encode,Decode}` utilities

1.2.1
  - Build against GHC 9.0
  - Build against `tasty` 1.3 and 1.4

1.2.0
  - Encode protobuf wire messages in reverse order to improve perfomance
  - Miscellaneous maintenance changes
