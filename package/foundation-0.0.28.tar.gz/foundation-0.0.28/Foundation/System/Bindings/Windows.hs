{-# OPTIONS_HADDOCK hide #-}
module Foundation.System.Bindings.Windows
     where
