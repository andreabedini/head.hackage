0.2.3.0
----------------
* template-haskell bumped to 2.17