# partial-isomorphism
[![Travis branch](https://img.shields.io/travis/schernichkin/partial-isomorphisms.svg)](https://travis-ci.org/schernichkin/partial-isomorphisms)
[![Hackage](https://img.shields.io/hackage/v/partial-isomorphisms.svg)](https://hackage.haskell.org/package/partial-isomorphisms)
