module Fib where

-- | Calculate Fibonacci numbers.
--
-- >>> putStrLn "foo"
-- foo
-- >>> putStr "bar"
-- bar
--
-- >>> putStrLn "baz"
-- baz
fib :: Int -> Int -> Int
fib _ = undefined
