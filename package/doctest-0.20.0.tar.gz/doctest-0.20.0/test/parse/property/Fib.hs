module Fib where

-- | Calculate Fibonacci numbers.
--
-- prop> foo
--
-- some text
--
-- prop> bar
--
-- some more text
--
-- prop> baz
fib :: Int -> Int -> Int
fib _ = undefined
