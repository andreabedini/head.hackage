module Foo where

-- $setup
-- some setup code

-- |
-- >>> foo
-- 23
foo :: Int
foo = 23
