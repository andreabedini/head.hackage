module Baz where

-- | documentation for baz
baz :: Int
baz = 23
