-- | Some documentation
module Foo where

foo :: Int
foo = 23
