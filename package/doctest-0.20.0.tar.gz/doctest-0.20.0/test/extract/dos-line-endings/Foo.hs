module Foo where

-- |
-- foo
-- bar
-- baz
foo :: Int
foo = 23
