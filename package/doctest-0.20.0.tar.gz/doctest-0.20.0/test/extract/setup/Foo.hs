module Foo where

-- $setup
-- some setup code

-- | foo
foo :: Int
foo = 42

-- | bar
bar :: Int
bar = 42

-- | baz
baz :: Int
baz = 42
