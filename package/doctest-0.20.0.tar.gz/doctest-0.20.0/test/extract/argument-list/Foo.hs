module Foo where

foo :: Int -- ^ doc for arg1
    -> Int -- ^ doc for arg2
    -> Int
foo = undefined
