module Foo where

-- |
-- prop> True
foo = undefined
