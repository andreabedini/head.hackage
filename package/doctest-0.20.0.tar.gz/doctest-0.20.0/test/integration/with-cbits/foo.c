int foo() {
  return 23;
}
