module Foo where

-- |
-- prop> abs x == abs (abs x)
foo = undefined
