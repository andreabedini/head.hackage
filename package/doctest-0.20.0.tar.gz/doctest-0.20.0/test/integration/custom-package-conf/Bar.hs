module Bar where

import Foo

-- |
-- >>> import Foo
-- >>> foo
-- 23
bar :: Int
bar = 42
