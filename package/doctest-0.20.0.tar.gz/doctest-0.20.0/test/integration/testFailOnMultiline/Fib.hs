module Fib where

-- | The following interaction cause `doctest' to fail with an error:
--
-- >>> :{
foo :: Int
foo = 23

-- | The following interaction cause `doctest' to fail with an error:
--
-- >>>       :{
bar :: Int
bar = 23
