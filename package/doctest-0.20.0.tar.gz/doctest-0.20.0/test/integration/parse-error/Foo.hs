module Foo where

-- | Some documentation
foo :: Int
foo =
