module A where

stderr :: Bool
stderr = True

stdout :: String
stdout = "hello"

-- |
-- >>> 3 + 3
-- 6
