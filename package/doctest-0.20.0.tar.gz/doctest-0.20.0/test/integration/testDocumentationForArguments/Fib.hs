module Fib where

fib :: Int -- ^ 
           -- >>> 23
           -- 23
    -> Int
fib _ = undefined
