module Foo where

-- | A failing example
--
-- >>> putStrLn "foo   "
-- foo
test :: a
test = undefined
