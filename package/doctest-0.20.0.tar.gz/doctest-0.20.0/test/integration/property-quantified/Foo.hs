module Foo where

-- |
-- prop> \x -> abs x == abs (abs x)
foo = undefined
