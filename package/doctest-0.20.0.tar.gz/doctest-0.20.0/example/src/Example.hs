module Example where

-- |
-- >>> foo
-- 23
foo = 23

-- |
-- >>> bar
-- 42
bar = 42
