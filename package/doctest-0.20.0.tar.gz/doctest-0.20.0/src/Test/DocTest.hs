module Test.DocTest (
  doctest
) where

import           Run
