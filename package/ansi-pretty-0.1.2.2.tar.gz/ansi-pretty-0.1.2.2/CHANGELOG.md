# 0.1.2.2

- Allow newer versions of dependencies: generics-sop-0.5, base-4.13

# 0.1.2.1

- Fix compilation issue with generics-sop-0.2.3.0

# 0.1.2.0

- `AnsiPretty` for other types in `time`

# 0.1.1.0

- Accept `generics-sop-0.2`
- Other upper bounds lifts
- `AnsiPretty Float` and `AnsiFloat Double`
