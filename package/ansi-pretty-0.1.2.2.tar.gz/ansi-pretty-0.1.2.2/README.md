# ansi-pretty

[![Build Status](https://travis-ci.org/futurice/haskell-ansi-pretty.svg?branch=master)](https://travis-ci.org/futurice/haskell-ansi-pretty)
[![Hackage](https://img.shields.io/hackage/v/ansi-pretty.svg)](http://hackage.haskell.org/package/ansi-pretty)

