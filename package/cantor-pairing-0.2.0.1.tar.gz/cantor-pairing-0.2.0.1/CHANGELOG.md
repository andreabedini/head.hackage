# Revision history for cantor-pairing

## 0.2.0.0

- `cantorEnumeration` is now productive in more cases due to better handling of large numbers internally (thanks Bodigrim!)

## 0.1.1.0

- Instances for `Int`, `Word`, `IntSet`, and `Set`
- Basic recursion is now detected generically, so there is now no need to manually specify that the cardinality is `Countable`

