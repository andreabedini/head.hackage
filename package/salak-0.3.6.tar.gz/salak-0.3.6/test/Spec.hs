-- file test/Spec.hs
{-# OPTIONS_GHC -F -pgmF hspec-discover #-}
