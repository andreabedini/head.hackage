# ChangeLog / ReleaseNotes


## Version 0.0.1

* First public release.
* Uploaded to [Hackage][]: <http://hackage.haskell.org/package/data-default-instances-new-base-0.0.1>

## Version 0.0.1.1

* Support for `data-default-class ==0.1.*`.
* Avoiding dependency on `data-default-instances-base` when building with
  `data-default-class >=0.1.2`.



[Hackage]:
  http://hackage.haskell.org/
  "HackageDB (or just Hackage) is a collection of releases of Haskell packages."
