Data-BWord
==========
This package provides extra (vs `Data.Bits`) operations on binary words of
fixed length.

Installation
------------
The usual:

	$ cabal install

