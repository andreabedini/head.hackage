# O.3.2 [Non-maintainer upload]

- Semigroup-Monoid compatibility (GHC-8.4)
