Change Log
==========

Version 1.0.5.0 (2017-06-05)
----------------

### New features

* Add settings to be able to change the character used to deliminate control statements #18

### Document updates

* Fixed small spelling/grammars on readme #19

Version 1.0.4.0 (2017-02-07)
----------------

### New features

* Expose htmlSetting and textSetting

Version 1.0.3.0 (2017-01-24)
----------------

### New features

* Add `case` control statement

Version 1.0.2.0 (2016-12-13)
----------------------------

#### New features

* Add `compileTextFileWith` and `compileHtmlFileWith` to inject extra variables
* Add `ScopeM` type for specifying extra template variables
* Add `setDefault` and `overwrite` for constructing `ScopeM`
