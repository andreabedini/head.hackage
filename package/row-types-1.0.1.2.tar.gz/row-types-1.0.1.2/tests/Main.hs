
module Main where

import Examples ()
import DiffPerformance ()
import MergePerformance ()
import UnionPerformance ()

main = putStrLn "Test passes if Examples.lhs type-checks."
